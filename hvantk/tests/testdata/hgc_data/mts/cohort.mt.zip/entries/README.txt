This folder comprises a Hail (www.hail.is) native Table or MatrixTable.
  Written with version 0.2.115-10932c754edb
  Created at 2025/10/24 16:04:19