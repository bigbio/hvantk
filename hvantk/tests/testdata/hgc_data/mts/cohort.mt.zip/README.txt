This folder comprises a Hail (www.hail.is) native Table or MatrixTable.
  Written with version 0.2.137-733ac4ccd943
  Created at 2026/02/02 11:54:25